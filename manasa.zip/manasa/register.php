<?php
$servername = "localhost:8080";
$username = "root";
$password = "root";
$dbname = "register";

//$title=$_REQUEST['sel1'];
$name=$_REQUEST['name'];
$birthdate=$_REQUEST['birthday'];
$gen=$_REQUEST['gender'];
$emailid=$_REQUEST['email'];
$phone=$_REQUEST['phone'];
$usn=$_REQUEST['usn'];
// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$sql = "INSERT INTO register (name, birthday, gender, email, phone, usn)
VALUES ('$name', '$birthdate', '$gen', '$emailid', '$phone', '$usn')";

if (mysqli_query($conn, $sql)) {
    echo "Insert successful";
} else {
    echo "magic failed: " . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);
?>
