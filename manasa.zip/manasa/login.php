<?php
$servername = "localhost:8889";
$username = "root";
$password = "root";
$dbname = "register";


$email=$_REQUEST['email'];
$usn=$_REQUEST['usn'];
$name=$_REQUEST['name'];

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$sql = "SELECT usn, email ,name FROM register WHERE usn='$usn' AND email='$email'AND name='$name'";
//SELECT usn, email ,name FROM register WHERE usn='1PE15CS033' AND email='test1@gmail.com' AND name='test2'

$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($result)) {
        echo "email: " . $row["email"]. "usn: " . $row["usn"]. " " ;
    }
} else {
    echo "Not Registered";
}

mysqli_close($conn);
?>
